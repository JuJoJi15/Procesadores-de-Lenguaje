public class ParEt {
    public String sv,sf;

      public ParEt(String v,String f){
        sv = v;
        sf = f;
      }
}
